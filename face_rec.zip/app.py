import numpy as np
import face_recognition as fr
import cv2





video_capture = cv2.VideoCapture(0)


arm_image = fr.load_image_file("arm.jpg")

arm_face_encoding = fr.face_encodings(arm_image)[0]

steve_image = fr.load_image_file("steve.jpg")

steve_face_encoding = fr.face_encodings(steve_image)[0]

elon_image = fr.load_image_file("elon.jpg")

elon_face_encoding = fr.face_encodings(elon_image)[0]

grig_image = fr.load_image_file("grig.jpg")

grig_face_encoding = fr.face_encodings(grig_image)[0]


known_face_encodings = [
arm_face_encoding,
steve_face_encoding,
elon_face_encoding,
grig_face_encoding]



known_face_names = [
"Armen",
"Steve",
"Elon Musk",
"Grig"]

while True:
    ret, frame = video_capture.read()

    rgb_frame = frame[:, :, ::-1]

    face_locations = fr.face_locations(rgb_frame)
    face_encodings = fr.face_encodings(rgb_frame, face_locations)

    for (top, right, bottom, left), face_encoding in zip(face_locations, face_encodings):
        matches = fr.compare_faces(known_face_encodings, face_encoding)

        name = "Ancanot"


        if True in matches:
            first_match_index = matches.index(True)
            name = known_face_names[first_match_index]

        cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)

        if name != "Ancanot":
            print(name + " was here")

        cv2.rectangle(frame, (left, bottom -35), (right, bottom), (0, 0, 255), cv2.FILLED)
        font = cv2.FONT_HERSHEY_SIMPLEX
        cv2.putText(frame, name, (left + 6, bottom - 6), font, 1.0, (255, 255, 255), 1)

    cv2.imshow('Webcam_facerecognition', frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

video_capture.release()
cv2.destroyAllWindows()
